import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-redirector',
  templateUrl: './redirector.component.html',
  styleUrls: ['./redirector.component.css']
})
export class RedirectorComponent implements OnInit {
  parameterValue: any ="";
  redirectURL : any = "";

  isHttp : boolean = true;

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.parameterValue = this.route.snapshot.paramMap.get('url');
    

    this.getLongUrl();

  }

  getLongUrl() {
    const url = 'http://localhost:8888/getLongUrl';
  


    const requestData = {
      _shortUrl: this.parameterValue
    };
  
    const xhr = new XMLHttpRequest();
    xhr.open('post', url, true);
    xhr.setRequestHeader('Content-Type', 'application/json');

    xhr.onreadystatechange = () => {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
          this.redirectURL = xhr.responseText;
          const checkForHTTP: string = 'http';

          const isHttpIncluded: boolean = this.redirectURL.includes(checkForHTTP);

          if(isHttpIncluded)
          {
            window.open(this.redirectURL, '_self');
            this.isHttp = true;
          }
          else{
            this.isHttp = false;
            this.redirectURL = "http://"+this.redirectURL;
            window.open(this.redirectURL, '_self');
          }         
         
        } else {
          console.error('Error occurred during POST request:', xhr.status);
        }
      }
    };

    xhr.send(JSON.stringify(requestData));
  }

  redirectToTarget() {
    window.open(this.redirectURL, '_blank');
  }
}
