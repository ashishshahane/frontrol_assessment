import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  longURL: String = "";
  shortURL: any = "";
  currentDate: Date = new Date();

  constructor(private http: HttpClient) { }

  test() {
    
    console.log(this.longURL);
    console.log(this.currentDate.toISOString());
    this.submitData();
    
  }

  submitData() {
    const url = 'http://localhost:8888/very/long/url';
  


    const requestData = {
      _longURL: this.longURL,
      _datetime: this.currentDate.toISOString()
    };
  
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);
    xhr.setRequestHeader('Content-Type', 'application/json');

    xhr.onreadystatechange = () => {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        if (xhr.status === 200) {
          this.shortURL =  "http://localhost:4200/tinyUrl/"+xhr.responseText;
        } else {
          console.error('Error occurred during POST request:', xhr.status);
        }
      }
    };

    xhr.send(JSON.stringify(requestData));
  }
  
}
