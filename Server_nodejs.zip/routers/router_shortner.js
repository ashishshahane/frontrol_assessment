const { Router } = require('express');
const shortner = require('../controllers/controller_shortner')

const app = Router();
app.post('/very/long/url', shortner);
module.exports = app;


