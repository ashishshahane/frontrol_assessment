const { Router } = require('express');
const redirecter = require('../controllers/controller_redirect')

const app = Router();
app.post('/getLongURL', redirecter);
module.exports = app;


