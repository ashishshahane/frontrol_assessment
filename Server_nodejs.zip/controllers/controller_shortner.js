var mysql = require('mysql2');

var tempLog = "non-edit";


var con = mysql.createConnection({
    host: "Ashish",
    user: "ashish",
    database: 'frontrol_test',
    password: "123456"
});

con.connect(function (err) {
    if (err) {
        tempLog = err;
        throw err;
    }
    else {
        tempLog = "no error found sql connected...!";
    }
});

const insertQuery = 'INSERT INTO frontrol_test.url_master SET ?';
module.exports = (req, res) => {

    req_longURL = req.body._longURL;
    req_shortURL = generateURL();

    const insertData = {
        redirect_url: req_longURL,
        short_url: req_shortURL
    };

    con.query(insertQuery, insertData, (err, results) => {
        if (err) {
            console.error('Error occurred during insert:', err);
            res.send('Error occurred during insert:', err);
        } else {
            console.log('Insert successful.');
            res.send(req_shortURL);
        }
    });
};

function generateURL() {
    const charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    const charsetLength = charset.length;
    for (let i = 0; i < 7; i++) {
        const randomIndex = Math.floor(Math.random() * charsetLength);
        result += charset.charAt(randomIndex);
    }
    return result;
}
