var mysql = require('mysql2');

var tempLog = "non-edit";

var con = mysql.createConnection({
    host: "Ashish",
    user: "ashish",
    database: 'frontrol_test',
    password: "123456"
});

con.connect(function (err) {
    if (err) {
        tempLog = err;
        throw err;
    }
    else {
        tempLog = "no error found sql connected...!";
    }
});


module.exports = (req, res) => {

    var surl = req.body._shortUrl;

    console.log('Requested param :', surl);  

    const query = "SELECT redirect_url AS rurl FROM frontrol_test.url_master where short_url = '"+surl+"'";

    con.query(query, (err, results) => {
      if (err) {
        console.error('Error executing query:', err);
        return;
      }
  
      const ridURL = results[0].rurl;
      console.log('Redirect URL :', ridURL);   
     
      res.send(ridURL);
    });
};

