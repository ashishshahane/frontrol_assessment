var express = require('express');
const cors = require("cors");
const bodyParser = require('body-parser');

const short = require('./routers/router_shortner');
const redir = require('./routers/router_redirect');

var app = express();
app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


var temp_port = "8888";

console.log("my port is: " + temp_port);
  
app.listen(temp_port,function(){
	console.log("server listening on port 8888");
});


app.use(short);
app.use(redir);



